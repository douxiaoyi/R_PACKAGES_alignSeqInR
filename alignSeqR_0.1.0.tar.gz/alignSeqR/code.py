
#!/usr/bin/python

import sys
from Bio import SeqIO
from Bio.Seq import Seq


def Alignment(A,B,Sigma,q,r):

# Match Score: 10;  Mismatch Score:-20  Gap-Open Penalty(q):40  Gap-Extension Penalty(r):2

    T = 0       #T is the sigma

    m = len(A)
    n = len(B)
    rowfirst = m
    colfirst = n

    S, D, I = [[0 for i in range(n + 1)] for j in range(m + 1)], [[0 for i in range(n + 1)] for j in
                                                                      range(m + 1)], [[0 for i in range(n + 1)] for j in
                                                                                   range(m + 1)]

    score = 0
    S[m][n] = 0
    D[m][n] = -(q + r)
    I[m][n] = -(q + r)

    for j in range(n - 1, -1, -1):
        S[m][j] = 0
        I[m][j] = -(q + r)
        D[m][j] = -(q + r)

    for i in range(m - 1, -1, -1):
        S[i][n] = 0
        I[i][n] = -(q + r)
        D[i][n] = -(q + r)

        for j in range(n - 1, -1, -1):
            # if element of two sequences are matched, sigma == 10, is mismatched sigma ==Sigma
            if A[i] == B[j]:
                T = 10
            else:
                T = Sigma
            D[i][j] = max(D[i + 1][j] - r, S[i + 1][j] - q - r)
            I[i][j] = max(I[i][j + 1] - r, S[i][j + 1] - q - r)
            S[i][j] = max(0, (S[i + 1][j + 1]) + T, D[i][j], I[i][j])

            if score < S[i][j]:
                score = S[i][j]
                rowfirst = i
                colfirst = j
    
    
    print ('Sequence A: ', A,'\n','Length: ',m,'\n')
    print ('Sequence B: ', B,'\n','Length: ',n,'\n')
    print( "  Match Score: 10;  \n  Mismatch Score: ",Sigma, "\n  Gap-Open Penalty: ",q,"\n  Gap-Extension Penalty: ",r,'\n')


    m, n = len(A), len(B)
    OA = []
    i = rowfirst
    j = colfirst
    mat = 'S'
    while i <= m and j <= n:
        if mat == 'S':
            if i == m or j == n or S[i][j] == 0:
                break
            if S[i][j] == D[i][j]:
                mat = 'D'
                continue
            if S[i][j] == I[i][j]:
                mat = 'I'
                continue
            OA.append((A[i], B[j]))
            i += 1
            j += 1
        if mat == 'D':
            OA.append((A[i], '-'))
            if i == m - 1 or D[i][j] == S[i + 1][j] - q - r:
                mat = 'S'
            i += 1
            continue
        if mat == 'I':
            OA.append(('-', B[j]))
            if j == n or I[i][j] == S[i][j + 1] - q - r:
                mat = 'S'
            j += 1
            continue
    
    rowlast = i
    collast = j
    OA1=''               #OA1 is the optimal alignment of sequenceA
    OA2=''               #OA2 is the optimal alignment of sequenceB
    middle=''            #middle is the middle line between these two sequences
    count = 0            #count is Number of matches and length of alignment - count is mismatches
    gapA=0
    gapB=0
    
    
    for item in OA:
       OA1 +=item[0]
       OA2 +=item[1]
    
    for a in range(len(OA1)):
        
        if OA1[a] == OA2[a]:
            middle += "|"
            count +=1
        else:
            middle +=' ' 
    Identity = count/len(OA)  #percent identity is the matches number / the length of alignment     
        
    for i in OA1:
        if i == '-':
            gapA +=1
    for i in OA2:
        if i == '-':
            gapB +=1 
    gap = gapA+gapB
    print ('Alignment Score: ' ,S[rowfirst][colfirst], '\n Length: '      ,len(OA),'\n')
    print ('Start Position in A: ',rowfirst+1,'\nStart Position in B: ',colfirst+1,'\n')
    print ('  End Position in A: ',rowlast,'\n  End Position in B: ',collast,'\n')
    print ('Number of matches: ',count,'\nNumber of mismatches: ',len(OA)-count-gap)
    print ('Length of gaps: ', gap)
    print ('Percent Identity: ',format(Identity,'0.2%'),'\n')
    
    
    endA = rowfirst
    endB = colfirst
    while (len(OA1)!=0):
        CA=0
        CB = 0
        sec1 = OA1[:70]  
        sec2 = middle[:70]  
        sec3 = OA2[:70]
        for i in sec1:
            if i != '-':
                CA+=1                   #CA and CB are numbers of un-gap alignment in each line
        for i in sec3:
            if i != '-':
                CB +=1
        startA =endA +1
        startB = endB+1
        endA = startA+ CA-1
        endB =startB + CB-1
        
        OA1 = OA1[70:]
        middle = middle[70:]
        OA2 = OA2[70:]

        
        print('\n')
        print(startA," "*10+ sec1,' ',endA)
        print(" "*(11+len(str(startA)))+ sec2)
        print(startB," "*10+ sec3,' ',endB)
    
    
def GC_Content(Seq):
    
    num = 0
    GC = 0
    for i in range(len(Seq)):
        
        if Seq[i] == 'G' or Seq[i] == 'C':
            num = num+1
        
            
    GC= format(num / len(Seq), '0.2%')    
    
    print( "GC_Content:" ,GC)
    

def Translation(Seq,fragment):
    
    reverse = Seq.reverse_complement()
    
    if fragment == 1:
        protein  = Seq.translate()
    if fragment == 2:
        protein = Seq[1:len(Seq)].translate()
    if fragment == 3:
        protein = Seq[2:len(Seq)].translate()
    if fragment == -1:
        protein = reverse.tranlate()
    if fragment == -2:
        protein = reverse[1:len(Seq)].tranlate()
    if fragment == -3:
        protein = reverse[2:len(Seq)].tranlate()
     
    return protein




if __name__ == '__main__':
    

    if len(sys.argv)==6:
        A = list(SeqIO.parse(sys.argv[1], "fasta"))
        B = list(SeqIO.parse(sys.argv[2], "fasta"))
        Sigma = int(sys.argv[3])
        q = int(sys.argv[4])
        r = int(sys.argv[5])
        print(Alignment(A[0].seq, B[0].seq,Sigma,q, r))
    if len(sys.argv) == 3:
        Seq = list(SeqIO.parse(sys.argv[1], "fasta"))
        fragment =int (sys.argv[2])
        print (Translation(Seq[0].seq,fragment))
    if len(sys.argv) == 2:
        Seq = list(SeqIO.parse(sys.argv[1], "fasta"))
        print (GC_Content(Seq[0].seq))
