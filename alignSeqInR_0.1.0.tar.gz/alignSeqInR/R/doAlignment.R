setwd("D:/Users/Administrator/Desktop/XIAOYI_DOU_HW1/")

python<- "E:/Python/python.exe"


doAlignment <- function(fastafilename1,fastafilname2,sigma,q,r){

  Sigma <- sigma
  Q<- Q
  R<-r
 # pyArgs <-sprintf("SeqA.fasta SeqB.fasta")
  pyArgs <- sprintf("%s %s",fastafilename1,fastafilname2)

  pyScript<- "D:/Users/Administrator/Desktop/XIAOYI_DOU_HW1/code.py"

  cmd<- sprintf("%s %s %s %d %d %d", python,pyScript,pyArgs,sigma,q,r)

  system(cmd)

}

GC_Content<- function(Seq){


  pyArgs <- sprintf("%s",Seq)
  pyScript<- "D:/Users/Administrator/Desktop/XIAOYI_DOU_HW1/code.py"

  cmd<- sprintf("%s %s %s", python,pyScript,pyArgs)

  system(cmd)

}




#doAlignment("SeqA.fasta","SeqB.fasta",-20,40,2)
