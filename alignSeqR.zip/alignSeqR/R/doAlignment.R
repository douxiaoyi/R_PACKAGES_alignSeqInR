
# library(devtools)
devtools::use_data_raw()
doAlignment <- function(fastafilename1,fastafilname2,sigma,q,r){

 Sigma <- sigma
  Q<- q
  R<-r

  Sigma<--20
  Q<-40
  R<-2

  pyArgs <-sprintf("SeqA.fasta SeqB.fasta")
  pyScript<- paste(system.file(package="alignSeqR"), "code.py", sep="/")

  python<- "python"

  pyScriptA <- paste("\"",pyScript,"\"",sep="")

  cmd<- sprintf("%s %s %s %d %d %d", python,pyScriptA,pyArgs,Sigma,Q,R)

  system(cmd)

}

GC_Content<- function(Seq){

  python<- "python"
  pyArgs <- sprintf("%s",Seq)
  pyScript<- paste(system.file(package="alignSeqR"), "code.py", sep="/")
  pyScriptA <- paste("\"",pyScript,"\"",sep="")

   cmd<- sprintf("%s %s %s", python,pyScriptA,pyArgs)

  system(cmd)

}




#doAlignment("SeqA.fasta","SeqB.fasta",-20,40,2)
